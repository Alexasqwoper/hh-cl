export default {
  ITEMS_PER_PAGE: 30,
  SITE_TITLE: 'React HN',
  UPDATES_CACHE_SIZE: 500
}
