var React = require('react')

var NotFound = React.createClass({
  render() {
    return <h2>Not found</h2>
  }
})

export default NotFound
